//
//  AppDelegate.m
//  demo
//
//

#import "AppDelegate.h"

@interface AppDelegate ()

@end

@implementation AppDelegate


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    NSLog(@"AppDelegate>>>>>");
    
    // 字面量一定不可能是Tagged Point
    /*
     是常量字符串的话，那么它永远不会存储为 tagged pointer 字符串。常量字符串必须保证能够兼容不同的操作系统版本，但 tagged pointer 字符串的内部细节却不保证能兼容。如果只是苹果的运行时代码所生成的 tagged pointer，它不会有任何问题。但如果像常量字符串一样，编译器把它们嵌入在二进制文件中时，就可能会发生崩溃的问题。
     */
    
    // 地址相等，同一个库中不同的文件中整的也是同一个地址，待验证不同库中的是不是相等
    // 0x10b1a711b，低地址，DATA段
    NSLog(@"\"NSObject\" %p", "NSObject");
    NSLog(@"\"NSObject\" %p", "NSObject");
    
    // __NSCFConstantString
    // 地址相等
    NSLog(@"@\"NSObject\".class %@", @"NSObject".class);
    NSLog(@"@\"NSObject\" %p", @"NSObject");
    NSLog(@"@\"NSObject\" %p", @"NSObject");
    
    // 地址相等
    // 常量字符串 转的 UTF8String 地址 跟 CString 的相等
    NSLog(@"[@\"NSObject\" UTF8String] %p", [@"NSObject" UTF8String]);
    NSLog(@"[@\"NSObject\" UTF8String] %p", [@"NSObject" UTF8String]);
    
    // NSTaggedPointerString
    // 地址相等
    NSLog(@"NSStringFromClass(NSObject.class) %@", NSStringFromClass(NSObject.class));
    NSLog(@"NSStringFromClass(NSObject.class).class %@", NSStringFromClass(NSObject.class).class);
    NSLog(@"NSStringFromClass(NSObject.class) %p", NSStringFromClass(NSObject.class));
    NSLog(@"NSStringFromClass(NSObject.class) %p", NSStringFromClass(NSObject.class));
    
    // 地址不同，[NSTaggedPointerString UTF8String]
    NSLog(@"[NSStringFromClass(NSObject.class) UTF8String] %p", [NSStringFromClass(NSObject.class) UTF8String]);
    NSLog(@"[NSStringFromClass(NSObject.class) UTF8String] %p", [NSStringFromClass(NSObject.class) UTF8String]);
    
    // __NSCFString
    // 地址不同
    NSLog(@"NSStringFromClass(self.class) %@", NSStringFromClass(self.class));
    NSLog(@"NSStringFromClass(self.class).class %@", NSStringFromClass(self.class).class);
    NSLog(@"NSStringFromClass(self.class) %p", NSStringFromClass(self.class));
    NSLog(@"NSStringFromClass(self.class) %p", NSStringFromClass(self.class));
    
    // 地址不同，[__NSCFString UTF8String]
    NSLog(@"[NSStringFromClass(self.class) UTF8String] %p", [NSStringFromClass(self.class) UTF8String]);
    NSLog(@"[NSStringFromClass(self.class) UTF8String] %p", [NSStringFromClass(self.class) UTF8String]);
    
    return YES;
}


#pragma mark - UISceneSession lifecycle


- (UISceneConfiguration *)application:(UIApplication *)application configurationForConnectingSceneSession:(UISceneSession *)connectingSceneSession options:(UISceneConnectionOptions *)options {
    // Called when a new scene session is being created.
    // Use this method to select a configuration to create the new scene with.
    return [[UISceneConfiguration alloc] initWithName:@"Default Configuration" sessionRole:connectingSceneSession.role];
}


- (void)application:(UIApplication *)application didDiscardSceneSessions:(NSSet<UISceneSession *> *)sceneSessions {
    // Called when the user discards a scene session.
    // If any sessions were discarded while the application was not running, this will be called shortly after application:didFinishLaunchingWithOptions.
    // Use this method to release any resources that were specific to the discarded scenes, as they will not return.
}


@end
