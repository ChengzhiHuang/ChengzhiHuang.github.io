//
//  ViewController.m
//  demo
//
//

#import "ViewController.h"

#import <objc/runtime.h>
#import <malloc/malloc.h>

// 继承只为了看什么时候调用 delloc，懒得引入 RAC 用监听了...
@interface WhenToDealloc : NSObject

@end


@implementation WhenToDealloc

- (void)dealloc {
    NSLog(@"dealloc");
}

@end

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    {
        __autoreleasing WhenToDealloc *whenToDealloc = [[WhenToDealloc alloc] init];
    }
    // dealloc when leave scope?
    
}
// dealloc when leave viewDidLoad?


- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    
}
// dealloc when leave viewWillAppear?

- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
    
}
// dealloc when leave viewDidAppear?


@end
