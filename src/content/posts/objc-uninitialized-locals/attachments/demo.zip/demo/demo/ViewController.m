//
//  ViewController.m
//  demo
//
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    for (NSInteger i = 0; i < 1000; i++) {
        BOOL defined = [self defined];
        BOOL undefined = [self undefined];
        NSAssert(undefined == NO, @""); // 如果认为 BOOL 未经初始化一定是 NO 的话，那这个 Assert 就永远不会中
    }
}

- (BOOL)defined {
    BOOL defined = YES;
    return defined;
}

- (BOOL)undefined{
    BOOL undefined;
    return undefined; // Variable 'undefined' is uninitialized when used here
}

@end



